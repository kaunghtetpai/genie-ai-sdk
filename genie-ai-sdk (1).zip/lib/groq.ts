import Groq from 'groq-sdk';

const groq = new Groq({
  apiKey: process.env.NEXT_PUBLIC_GROQ_API_KEY || '',
});

export async function askGenie(question: string) {
  const chat = await groq.chat.completions.create({
    model: 'llama-3-8b-8192',
    messages: [{ role: 'user', content: question }],
  });
  return chat.choices[0]?.message?.content || 'မဖြေနိုင်ပါ';
}

export default groq;

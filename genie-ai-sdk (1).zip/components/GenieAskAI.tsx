'use client';
import { useState } from 'react';
import { askGenie } from '../lib/groq';
import type { Message } from '../types/ai';

export default function GenieAskAI() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!input.trim()) return;
    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setLoading(true);
    const reply = await askGenie(input);
    const assistantMessage: Message = { role: 'assistant', content: reply };
    setMessages((prev) => [...prev, assistantMessage]);
    setInput('');
    setLoading(false);
  };

  return (
    <div className="card-primary glass glow max-w-2xl mx-auto mt-10 p-6 water-ripple space-y-4">
      <h2 className="heading-2">eSIM Myanmar Ask AI</h2>
      <div className="space-y-2 max-h-96 overflow-y-auto">
        {messages.map((m, i) => (
          <div key={i} className={`p-3 rounded-lg ${m.role === 'user' ? 'bg-[#263A49]' : 'bg-[#1E2F3C]'}`}>
            <p className="text-body whitespace-pre-wrap">{m.content}</p>
          </div>
        ))}
      </div>
      <textarea
        className="input-primary w-full"
        rows={3}
        placeholder="မေးခွန်းရေးပါ / Type your question..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button onClick={handleAsk} className="btn-primary w-full" disabled={loading}>
        {loading ? 'Genie စဉ်းစားနေပါသည်...' : 'Genie AI ကို မေးမည်'}
      </button>
    </div>
  );
}

# Genie AI SDK – eSIM Myanmar Ask AI

> Bilingual (English / မြန်မာ) AI assistant using Groq.ai LLaMA-3

## 🌐 English

Genie AI SDK is a React-based assistant component for eSIM Myanmar using Groq LLaMA-3. It supports English and Burmese.

### Usage

```tsx
import { GenieAskAI } from 'genie-ai-sdk';
<GenieAskAI />
```

### Env

```env
NEXT_PUBLIC_GROQ_API_KEY=your_key
```

## 🇲🇲 မြန်မာ

Genie AI SDK သည် Groq.ai LLaMA3 ကို အသုံးပြု၍ မြန်မာလို မေးမြန်းနိုင်သော React SDK ဖြစ်သည်။

```env
NEXT_PUBLIC_GROQ_API_KEY=သင့် key
```
